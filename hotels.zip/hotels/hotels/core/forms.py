from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

COUNTRIES = (
    (1, 'Türkiye'),
    (2, 'Brezilya'),
    (3, 'Hindistan'),
    (4, 'Kanada'),
    (5, 'Almanya'),
    (6, 'Japonya'),
    (7, 'Avustralya'),
    (8, 'Meksika'),
    (9, 'Fransa'),
    (10, 'Güney Afrika'),
    (11, 'Rusya'),
    (12, 'İtalya'),
    (13, 'Birleşik Krallık'),
    (14, 'Çin'),
    (15, 'İspanya'),
    (16, 'Arjantin'),
    (17, 'Güney Kore'),
    (18, 'Nijerya'),
    (19, 'Suudi Arabistan'),
    (20, 'Amerika Birleşik Devletleri'),
)

CITIES = (
    (1, 'İstanbul'),
    (2, 'Ankara'),
    (3, 'İzmir'),
    (4, 'Bursa'),
    (5, 'Adana'),
    (6, 'Antalya'),
    (7, 'Konya'),
    (8, 'Gaziantep'),
    (9, 'Mersin'),
    (10, 'Diyarbakır'),
    (11, 'Kayseri'),
    (12, 'Eskişehir'),
    (13, 'Aydın'),
    (14, 'Trabzon'),
    (15, 'Erzurum'),
    (16, 'Samsun'),
    (17, 'Malatya'),
    (18, 'Kocaeli'),
    (19, 'Denizli'),
    (20, 'Şanlıurfa'),
)
    
class SignUpForm(UserCreationForm):
    username = forms.CharField(label='Kullanıcı Adı', max_length=30)
    email = forms.EmailField(label='Email')
    first_name = forms.CharField(label='Ad', max_length=100)
    last_name = forms.CharField(label='Soyad', max_length=100)
    country = forms.ChoiceField(label='Ülke', choices=COUNTRIES)
    city = forms.ChoiceField(label='Şehir', choices=CITIES)
    class Meta:
        model = User
        fields = ('first_name','last_name','username', 'email', 'password1', 'password2')
        
