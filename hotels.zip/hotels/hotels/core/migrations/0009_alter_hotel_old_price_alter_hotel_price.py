from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('core', '0008_alter_hotel_old_price_alter_hotel_price'),
    ]

    operations = [
        migrations.AlterField(
            model_name='hotel',
            name='old_price',
            field=models.DecimalField(decimal_places=2, default='2.99', max_digits=9999999),
        ),
        migrations.AlterField(
            model_name='hotel',
            name='price',
            field=models.DecimalField(decimal_places=2, default='1.99', max_digits=9999999),
        ),
    ]
